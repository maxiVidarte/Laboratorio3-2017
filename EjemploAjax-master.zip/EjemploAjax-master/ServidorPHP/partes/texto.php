	<p><strong>1-</strong> Mostrar en el principal los datos retornados como JSON de Argentina  </p>
	<p><strong>2-</strong> Mostrar en el principal los datos retornados como JSON de toda America  </p>
	<p><strong>3-</strong> Mostrar en el principal si el numero random generado es positivo o negativo </p>
	<p><strong>4-</strong> Pasar los parametros por GET para el maximo y el minimo del random </p>
	<p><strong>5-</strong> Pasar los parametros por POST para el maximo y el minimo del random </p>
	<p><strong>6-</strong> Si el numero random es par  guardarlo con "GuardarNumero" de js </p>
	