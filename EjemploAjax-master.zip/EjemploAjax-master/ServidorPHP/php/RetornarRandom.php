<?php 

sleep(2);
echo rand(-100, 100);

?>